import AdminClient from './AdminClient';
export default function Admin(){return <AdminClient/>}
