import './globals.css';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
export const metadata={title:'MyHome Finder | Your Property. Your Future.',description:'Discover houses, flats and plots across Visakhapatnam with MyHome Finder.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><Header/><main>{children}</main><Footer/></body></html>}
