import { createBrowserClient } from '@supabase/ssr';
export function supabase() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) throw new Error('Supabase is not configured. Copy .env.example to .env.local and add your project URL and anon key.');
  return createBrowserClient(url, key);
}
